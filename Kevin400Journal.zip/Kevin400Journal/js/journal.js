$(document).ready(function(){

  $("div").hover(
    function(){
        $(this).addClass("active");
    },
    function(){
        $(this).removeClass("active");
    },
    function(){
    	$("div").addClass("active");
    },
    function(){
    	$("div").removeClass("active");
    }
  );


});